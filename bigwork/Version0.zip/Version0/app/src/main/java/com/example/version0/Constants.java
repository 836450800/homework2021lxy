package com.example.version0;

public class Constants {
    public static final String BASE_URL = "https://api-android-camp.bytedance.com/zju/invoke/";
    public static final String token = "WkpVLWJ5dGVkYW5jZS1hbmRyb2lk";
    public static final String STUDENT_ID = "3190102514";
    public static String USER_NAME = "龙香遇";
    public static String search_id = "";

}
